package telinfoDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import telinfoDBConn.TelInfoDBConn;
import telinfoVO.TelInfoVO;

public class TelInfoDAO {
	private Connection con;
	PreparedStatement pstmt =null;
	ResultSet rs=null;
	
	public TelInfoDAO() throws ClassNotFoundException, SQLException{
		con= new TelInfoDBConn().getConnection();
	}
	public void pstmtClose() throws SQLException{
		if(pstmt != null) {pstmt.close();}
		
	}
	public void getAllInfoClose() throws SQLException{
		if(rs != null) {rs.close();}
		if(pstmt != null) {pstmt.close();}
		if(con != null) {con.close();}
	}
	
	//반환형 //메소드명 3형식
	public ArrayList<TelInfoVO> getAllInfo() throws SQLException{
		ArrayList<TelInfoVO> tiarray = new ArrayList<TelInfoVO>();
		String sql= "SELECT * FROM TelTable5 ORDER BY id";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		while(rs.next()) {
		int id = rs.getInt("id");
		String name = rs.getString("name");
		String tel = rs.getString("tel");
		Date d = rs.getDate("d");
		
		TelInfoVO tv = new TelInfoVO(id,name,tel,d); //VO 생성자 활용
		tiarray.add(tv); //ArrayList 컬렉션에 객체 넣기
	}
	return tiarray; //전체 내용이들어있는 해당 컬렉션을 리턴
	}
	
	public boolean update_nametel(String tel2, String name2) { //수정메소드
		//수정은 이름조건에 대하여 전화번호만 수정 하기로 하자, 그리고 DB테이블로 저장된다
		//새로운 전화번호 및 수정대상사원이름은 jsp로부터 온다.
		//그리고 처리 후 error가 나면 false, 아니면 true를 리턴하기로 한다.
		String sql="update TelTable5 set tel=? where name=?";
		
		try{
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, tel2);
			pstmt.setString(2, name2);
			pstmt.executeUpdate();
		}catch(SQLException e) {
			System.out.println("update Exception");
			return false;
		}
		return true;
	}
	
	public TelInfoVO search_nametel(String oriName) throws SQLException{ /*1명 검색하는 메소드. 수정할 때 필요*/
		TelInfoVO tv= null;
		String sql="select * From TelTable5 where name=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, oriName);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			int id=rs.getInt("id");
			String name=rs.getString("name");
			String tel=rs.getString("tel");
			Date d=rs.getDate("d");
			tv=new TelInfoVO(id,name,tel,d);
		}else
		{tv=null;}
		return tv;
	}
	
	public boolean insert_nametel(int id,String name, String tel, String sDate) {
		String sql="insert into TelTable5 values(?,?,?,?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, tel);
			int year = Integer.parseInt(sDate.substring(0,4))-1900;
			int month = Integer.parseInt(sDate.substring(4,6))-1;
			int day = Integer.parseInt(sDate.substring(6,8));
			Date d = new Date(year,month,day);
			pstmt.setDate(4, d);
			pstmt.executeUpdate();
		}catch(SQLException e) {
			System.out.println("insert Exception");
			return false;
			}
		return true;
	}
	
	public boolean delete_nametel(String name2) {
		String sql="delete from TelTable5 where name=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name2);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("delete Exception");
			return false;
		}
		return true;
	}
	
}
