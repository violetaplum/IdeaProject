select * from TELTABLE5;

update teltable5 set id=2, name='kim', tel='3333',D='2019-06-06' where name='hong';

delete from teltable5 where id = 789;