package com.telservlet.my;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import telinfoDAO.TelInfoDAO;
import telinfoVO.TelInfoVO;

/**
 * Servlet implementation class Telinsert
 */
@WebServlet("/Telinsert")
public class Telinsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Telinsert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*4개의 필드를 전부 입력받아 DAO를 통해 DB에 저장. 저장OK이면 true, 아니면 false를 통해 결과를 확인하고 jsp가 그것을 처리하도록 보내야된다*/
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String kaja=null;
		TelInfoDAO tidao=null;
		
		
		try {
			tidao=new TelInfoDAO();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String tel=request.getParameter("tel");
		String sDate=request.getParameter("sDate");
		
		boolean tv3 = tidao.insert_nametel(id,name,tel,sDate);
		
		if(tv3) {
			request.setAttribute("result1", "입력good");
		}else{request.setAttribute("result1", "에러");
		}
		kaja="result.jsp";
		RequestDispatcher rd1=request.getRequestDispatcher(kaja);
		rd1.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
